import React from 'react'

export default function DashboardComponent() {
  return (
    <div>dashboardComponent</div>
  )
}
