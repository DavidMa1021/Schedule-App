import logo from './logo.svg';
import './App.css';
import NavBarComponent from './components/nav-bar-component';

function App() {
  return (
    <NavBarComponent />
  );
}

export default App;
